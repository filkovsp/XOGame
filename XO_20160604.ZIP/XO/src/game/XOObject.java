/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author Pavel
 */
public class XOObject {
    private final String name;
    private boolean signed = false;   
    private Object userObject = null;

    /**
     * Constructs an empty object container with the given Name
     * @param name 
     */
    public XOObject (String name) {
        this.name = name;
        this.signed = false;
    }
    
    /**
     * Constructs an empty object container with the given NAME and SELECTED property.
     * @param name 
     */
    public XOObject (String name, boolean signed) {
        this.name = name;
        this.signed = signed;
    }
    
    /**
     * Returns User Object
     * @return 
     */
    public Object getUserObject() {
        return this.userObject;
    }
    
    /**
     * Sets User Object
     * @param obj 
     */
    public void setUserObject(Object obj) {
        this.userObject = obj;
    }
    
    /**
     * Marks Object as signed, means the corresponded xoCell has been defiled with X|O
     * @param signed 
     */
    public void setSigned (boolean signed) {
        this.signed = signed;
    }
    
    /**
     * Returns true if current cell in xoMatrix is already defined with sign X|O
     * @return true|false from internal field "signed"
     */
    public boolean isSigned () {
        return this.signed;
    }
    
    @Override
    public String toString() {
        return this.name;
    }

}
