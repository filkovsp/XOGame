/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author Pavel
 */
public class FieldChangeListener implements FieldListener {

    FieldChangeListener(String sign, Object obj) {
        
    }

    @Override
    public void fieldValueChanged(String fieldName, Object newValue) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        System.out.println(this.getClass().toString() + "." + 
                fieldName + " has got new value: " + newValue);
    }
    
}
